from django.apps import AppConfig


class FacultyinfoConfig(AppConfig):
    name = 'FacultyInfo'
