from django.db import models
from datetime import datetime
# Create your models 

class PersonalInfo(models.Model):
	rollNo = models.CharField(max_length=20)
	first_name = models.CharField(max_length=30)
	last_name = models.CharField(max_length=30)
	address = models.TextField(max_length=30)
	email = models.EmailField(max_length=30)
	phoneNo = models.IntegerField(max_length=20)

class AcademicsInfo(models.Model):
	yearOfJoining= models.IntegerField(max_length=30)
	aggregate = models.IntegerField(max_length=30)
	upperSecondaryInstitution = models.CharField(max_length=70)
	upperSecondaryBoard = models.CharField(max_length=30)
	upperSecondaryPercentage = models.IntegerField(max_length=10)
	secondaryPercentage = models.IntegerField(max_length=10)
	secondaryInstitution = models.CharField(max_length=10)
	secondaryBoard = models.CharField(max_length=10)
	studentId = models.ForeignKey(PersonalInfo, on_delete = models.CASCADE)

class Notifications(models.Model):
	driveName = models.ForeignKey(PersonalInfo, on_delete = models.CASCADE)
	date = models.TextField()
	notification = models.CharField(max_length=30)
    


