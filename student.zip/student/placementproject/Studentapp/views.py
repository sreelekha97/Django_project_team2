from django.shortcuts import render,redirect,render_to_response
from Studentapp.forms import PersonInfoForm
from Studentapp.models import PersonalInfo
from django.http import HttpResponse,HttpResponseRedirect



def index(request):
	return HttpResponse("Welcome to Student info system")


def base(request):
	if request.method == "POST":
		form = PersonInfoForm(request.POST)
		if form.is_valid():
			PersonalInfo = form.save(commit=False)
			PersonalInfo.save()
			return redirect('success')
	else:
		form = PersonInfoForm()
	return render(request, 'Studentapp/base.html', {'form': form})


def display(request):
	try:
		Student = PersonalInfo.objects.all()
	except PersonalInfo.DoesNotExist:
		raise Http404("Comment does not exist")
	return render(request, "Studentapp/display.html",{'Student': Student})
