from django.shortcuts import render

# Create your views here.

def propic(request):
    return render(request, 'pp/p_p.html', {})
