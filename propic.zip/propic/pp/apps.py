from django.apps import AppConfig


class PpConfig(AppConfig):
    name = 'pp'
